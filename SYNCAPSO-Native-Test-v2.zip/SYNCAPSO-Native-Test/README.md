# SYNCAPSO Native Test

Separate test build for SYNCAPSO. Package: `com.syncapso.app.test`, so it will not replace the current app.

Features included in this test project:
- Native Jetpack Compose mobile-first UI
- Home dashboard and live study timer
- Persistent active timer recovery
- Chapters with Physics/Chemistry/Biology
- Lecture/DPP structure, exactly 5 Revision slots, NCERT/PYQ/Test
- Batch tasks linked bidirectionally with chapter checkpoints
- Manual To-Do tasks
- Persistent AI chat history
- Study history starter screen

Build with Android Studio / Gradle 8.9, Android SDK 35.
