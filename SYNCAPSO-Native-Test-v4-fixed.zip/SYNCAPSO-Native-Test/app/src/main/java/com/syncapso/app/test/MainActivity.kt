package com.syncapso.app.test

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight as UiFontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val Lavender = Color(0xFFF7F4FF)
private val Purple = Color(0xFF7357E8)
private val Green = Color(0xFF38B979)
private val Blue = Color(0xFF4E8DF7)

data class Todo(val id:String,val text:String,var done:Boolean,val chapterId:String?=null,val kind:String?=null,val index:Int?=null,val batch:Boolean=false)
data class Chapter(val id:String,val subject:String,var name:String,var locked:Boolean=false,val lectures:MutableList<Boolean> = mutableListOf(),val dpps:MutableList<Boolean> = mutableListOf(),val revisions:MutableList<Boolean> = MutableList(5){false},var ncert:Boolean=false,var pyq:Boolean=false,var test:Boolean=false)
data class Chat(val role:String,val text:String)

class SyncapsoVM(private val ctx:Context): ViewModel() {
    private val prefs=ctx.getSharedPreferences("syncapso_native_test",Context.MODE_PRIVATE)
    var screen by mutableStateOf("Home"); private set
    var subject by mutableStateOf("All")
    var todos by mutableStateOf(loadTodos())
    var chapters by mutableStateOf(loadChapters())
    var chats by mutableStateOf(loadChats())
    var selectedChapter by mutableStateOf<String?>(null)
    var timerRunning by mutableStateOf(false); private set
    var timerStarted by mutableStateOf(0L); private set
    var now by mutableLongStateOf(System.currentTimeMillis()); private set
    var manualText by mutableStateOf("")
    var aiText by mutableStateOf("")
    var aiBusy by mutableStateOf(false)
    init { recoverTimer(); viewModelScope.launch { while(true){ now=System.currentTimeMillis(); delay(500) } } }
    private fun loadTodos():MutableList<Todo>{ val a=JSONArray(prefs.getString("todos","[]")); return MutableList(a.length()){i->val o=a.getJSONObject(i);Todo(o.getString("id"),o.getString("text"),o.optBoolean("done"),o.optString("cid").ifBlank{null},o.optString("kind").ifBlank{null},if(o.has("idx"))o.optInt("idx") else null,o.optBoolean("batch"))} }
    private fun saveTodos(){val a=JSONArray();todos.forEach{a.put(JSONObject().apply{put("id",it.id);put("text",it.text);put("done",it.done);put("cid",it.chapterId);put("kind",it.kind);put("idx",it.index);put("batch",it.batch)})};prefs.edit().putString("todos",a.toString()).apply()}
    private fun loadChapters():MutableList<Chapter>{val a=JSONArray(prefs.getString("chapters","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Chapter(o.getString("id"),o.getString("subject"),o.getString("name"),o.optBoolean("locked"),jsonBools(o.optJSONArray("lec")),jsonBools(o.optJSONArray("dpp")),jsonBools(o.optJSONArray("rev"),5),o.optBoolean("ncert"),o.optBoolean("pyq"),o.optBoolean("test"))}}
    private fun jsonBools(a:JSONArray?,n:Int?=null)=MutableList(n?:a?.length()?:0){a?.optBoolean(it)?:false}
    private fun saveChapters(){val a=JSONArray();chapters.forEach{c->a.put(JSONObject().apply{put("id",c.id);put("subject",c.subject);put("name",c.name);put("locked",c.locked);put("lec",JSONArray().apply{c.lectures.forEach{put(it)}});put("dpp",JSONArray().apply{c.dpps.forEach{put(it)}});put("rev",JSONArray().apply{c.revisions.forEach{put(it)}});put("ncert",c.ncert);put("pyq",c.pyq);put("test",c.test)})};prefs.edit().putString("chapters",a.toString()).apply()}
    private fun loadChats():MutableList<Chat>{val a=JSONArray(prefs.getString("chats","[]"));return MutableList(a.length()){i->{val o=a.getJSONObject(i);Chat(o.getString("r"),o.getString("t"))}}}
    private fun saveChats(){val a=JSONArray();chats.forEach{a.put(JSONObject().put("r",it.role).put("t",it.text))};prefs.edit().putString("chats",a.toString()).apply()}
    private fun recoverTimer(){val s=prefs.getLong("active_timer",0);if(s>0){val mins=((System.currentTimeMillis()-s)/60000).coerceAtLeast(0);prefs.edit().remove("active_timer").apply();if(mins>0) prefs.edit().putInt("today_minutes",prefs.getInt("today_minutes",0)+mins.toInt()).apply()}}
    fun go(s:String){screen=s}
    fun startStop(){if(!timerRunning){timerStarted=System.currentTimeMillis();timerRunning=true;prefs.edit().putLong("active_timer",timerStarted).apply()}else{val mins=((System.currentTimeMillis()-timerStarted)/60000).coerceAtLeast(1);prefs.edit().putInt("today_minutes",prefs.getInt("today_minutes",0)+mins.toInt()).remove("active_timer").apply();timerRunning=false;timerStarted=0}}
    fun addChapter(sub:String,name:String){chapters=(chapters+Chapter(UUID.randomUUID().toString(),sub,name)).toMutableList();saveChapters()}
    fun toggleCheckpoint(c:Chapter,kind:String,idx:Int?=null){when(kind){"lec"->if(idx!=null)c.lectures[idx]=!c.lectures[idx];"dpp"->if(idx!=null)c.dpps[idx]=!c.dpps[idx];"rev"->if(idx!=null)c.revisions[idx]=!c.revisions[idx];"ncert"->c.ncert=!c.ncert;"pyq"->c.pyq=!c.pyq;"test"->c.test=!c.test};val t=todos.firstOrNull{it.batch&&it.chapterId==c.id&&it.kind==kind&&it.index==idx};if(t!=null)t.done=checkpointDone(c,kind,idx);saveChapters();saveTodos();chapters=chapters.toMutableList();todos=todos.toMutableList()}
    private fun checkpointDone(c:Chapter,k:String,i:Int?)=when(k){"lec"->c.lectures.getOrNull(i?:-1)==true;"dpp"->c.dpps.getOrNull(i?:-1)==true;"rev"->c.revisions.getOrNull(i?:-1)==true;"ncert"->c.ncert;"pyq"->c.pyq;"test"->c.test;else->false}
    fun addBatch(c:Chapter,k:String,i:Int?=null){if(todos.none{it.batch&&it.chapterId==c.id&&it.kind==k&&it.index==i}){todos=(todos+Todo(UUID.randomUUID().toString(),label(k,i,c),false,c.id,k,i,true)).toMutableList();saveTodos()}}
    private fun label(k:String,i:Int?,c:Chapter)=when(k){"lec"->"${c.name} • Lecture ${i!!+1}";"dpp"->"${c.name} • DPP ${i!!+1}";"rev"->"${c.name} • Revision ${i!!+1}";"ncert"->"${c.name} • NCERT";"pyq"->"${c.name} • PYQ";else->"${c.name} • Test"}
    fun toggleTodo(t:Todo){t.done=!t.done;if(t.batch){chapters.firstOrNull{it.id==t.chapterId}?.let{c->val k=t.kind?:"";val i=t.index;when(k){"lec"->if(i!=null)c.lectures[i]=t.done;"dpp"->if(i!=null)c.dpps[i]=t.done;"rev"->if(i!=null)c.revisions[i]=t.done;"ncert"->c.ncert=t.done;"pyq"->c.pyq=t.done;"test"->c.test=t.done}}};saveTodos();saveChapters();todos=todos.toMutableList();chapters=chapters.toMutableList()}
    fun addManual(){val x=manualText.trim();if(x.isNotEmpty()){todos=(todos+Todo(UUID.randomUUID().toString(),x,false)).toMutableList();manualText="";saveTodos()}}
    fun askAI(){val q=aiText.trim();if(q.isEmpty()||aiBusy)return;chats=(chats+Chat("user",q)).toMutableList();aiText="";saveChats();aiBusy=true;viewModelScope.launch{delay(700);val reply="Got it. I’m your SYNCAPSO tutor. For this test build, AI connection is ready to be wired to your existing backend. Your question was: $q";chats=(chats+Chat("assistant",reply)).toMutableList();saveChats();aiBusy=false}}
    fun addStructure(c:Chapter,lec:Int,dpp:Int){if(!c.locked){repeat(lec){c.lectures.add(false)};repeat(dpp){c.dpps.add(false)};c.locked=true;saveChapters();chapters=chapters.toMutableList()}}
    fun clearChat(){chats.clear();saveChats();chats=chats.toMutableList()}
    fun todayMinutes(): Int = prefs.getInt("today_minutes",0)
    fun elapsed()=((if(timerRunning)System.currentTimeMillis() else timerStarted)-timerStarted).coerceAtLeast(0)
}

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{val vm:SyncapsoVM=viewModel(factory=object:androidx.lifecycle.ViewModelProvider.Factory{override fun <T:ViewModel> create(c:Class<T>)=SyncapsoVM(this@MainActivity) as T});App(vm)}}}

@Composable fun App(vm:SyncapsoVM){MaterialTheme(colorScheme=lightColorScheme(primary=Purple,background=Lavender,surface=Color.White)){Scaffold(containerColor=Lavender,bottomBar={NavigationBar(containerColor=Color.White){listOf("Home" to Icons.Default.Home,"Chapters" to Icons.Default.MenuBook,"To-Do" to Icons.Default.CheckCircle,"History" to Icons.Default.CalendarMonth,"AI" to Icons.Default.SmartToy).forEach{(n,i)->NavigationBarItem(selected=vm.screen==n,onClick={vm.go(n)},icon={Icon(i,null)},label={Text(n)})}}}){p->Box(Modifier.padding(p).fillMaxSize()){when(vm.screen){"Home"->Home(vm);"Chapters"->Chapters(vm);"Chapter"->vm.selectedChapter?.let{id->vm.chapters.firstOrNull{it.id==id}?.let{c->ChapterDetail(vm,c)}} ?: Chapters(vm);"To-Do"->Todos(vm);"History"->History(vm);"AI"->AI(vm)}}}}}

@Composable fun Header(title:String,sub:String=""){Column(Modifier.padding(horizontal=20.dp,vertical=18.dp)){Text(title,fontSize=28.sp,fontWeight=UiFontWeight.Bold);if(sub.isNotBlank())Text(sub,color=Color.Gray,fontSize=14.sp)}}
@Composable fun CardBox(mod:Modifier=Modifier,content:@Composable ColumnScope.()->Unit){Card(mod.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp),content=content)}

@Composable fun Home(vm:SyncapsoVM){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){item{Header("Good morning 👋","Your NEET study dashboard")};item{CardBox{Column(Modifier.padding(18.dp)){Text("Study timer",fontWeight=UiFontWeight.SemiBold);Spacer(Modifier.height(8.dp));val e=vm.elapsed();Text(String.format("%02d:%02d:%02d",e/3600000,(e/60000)%60,(e/1000)%60),fontSize=42.sp,fontWeight=UiFontWeight.Bold);Button(onClick={vm.startStop()},modifier=Modifier.fillMaxWidth()){Text(if(vm.timerRunning)"Stop & Save" else "Start studying")}}}};item{Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Metric("Today", "${vm.todayMinutes()} min");Metric("Tasks","${vm.todos.count{!it.done}} left")}};item{CardBox{Column(Modifier.padding(18.dp)){Text("Today’s To-Do",fontWeight=UiFontWeight.Bold);vm.todos.filter{!it.done}.take(4).forEach{Text("• ${it.text}",Modifier.padding(top=8.dp))};if(vm.todos.none{!it.done})Text("All clear 🎉",Modifier.padding(top=8.dp),color=Green)}}}}
@Composable fun Metric(a:String,b:String)=CardBox(Modifier.weight(1f)){Column(Modifier.padding(16.dp)){Text(a,color=Color.Gray);Text(b,fontWeight=UiFontWeight.Bold,fontSize=22.sp)}}

@Composable fun Chapters(vm:SyncapsoVM){var add by remember{mutableStateOf(false)};LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Header("Chapters","Build your study structure")};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("All","Physics","Chemistry","Biology").forEach{FilterChip(selected=vm.subject==it,onClick={vm.subject=it},label={Text(it)})}}};items(vm.chapters.filter{vm.subject=="All"||it.subject==vm.subject}){c->CardBox(Modifier.clickable{vm.selectedChapter=c.id;vm.go("Chapter")}){Column(Modifier.padding(18.dp)){Text(c.subject.uppercase(),color=Purple,fontSize=12.sp,fontWeight=UiFontWeight.Bold);Text(c.name,fontSize=20.sp,fontWeight=UiFontWeight.Bold);Text("${c.lectures.count{it}}/${c.lectures.size} lectures • ${c.dpps.count{it}}/${c.dpps.size} DPPs • ${c.revisions.count{it}}/5 revisions",color=Color.Gray,modifier=Modifier.padding(top=5.dp));LinearProgressIndicator(progress={progress(c)},modifier=Modifier.fillMaxWidth().padding(top=12.dp))}}};item{Button(onClick={add=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Add chapter")}}};if(add)AddChapterDialog({s,n->vm.addChapter(s,n);add=false},{add=false})}
fun progress(c:Chapter)=((c.lectures.count{it}+c.dpps.count{it}+c.revisions.count{it}+listOf(c.ncert,c.pyq,c.test).count{it}).toFloat()/((c.lectures.size+c.dpps.size+8).coerceAtLeast(1)))

@Composable fun AddChapterDialog(ok:(String,String)->Unit,cancel:()->Unit){var s by remember{mutableStateOf("Physics")};var n by remember{mutableStateOf("")};AlertDialog(onDismissRequest=cancel,title={Text("New chapter")},text={Column{Row{listOf("Physics","Chemistry","Biology").forEach{FilterChip(selected=s==it,onClick={s=it},label={Text(it)},modifier=Modifier.padding(end=4.dp))}};OutlinedTextField(n,{n=it},label={Text("Chapter name")},modifier=Modifier.fillMaxWidth().padding(top=12.dp))}},confirmButton={TextButton(enabled=n.isNotBlank(),onClick={ok(s,n)}){Text("Add")}},dismissButton={TextButton(onClick=cancel){Text("Cancel")}})}

@Composable fun ChapterDetail(vm:SyncapsoVM,c:Chapter){var lec by remember{mutableIntStateOf(c.lectures.size)};var dpp by remember{mutableIntStateOf(c.dpps.size)};LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Header(c.name,c.subject)};if(!c.locked)item{CardBox{Column(Modifier.padding(16.dp)){Text("Plan structure",fontWeight=UiFontWeight.Bold);Row(verticalAlignment=Alignment.CenterVertically){Text("Lectures");Spacer(Modifier.weight(1f));Text("$lec");IconButton({if(lec>0)lec--}){Icon(Icons.Default.Remove,null)};IconButton({lec++}){Icon(Icons.Default.Add,null)}};Row(verticalAlignment=Alignment.CenterVertically){Text("DPPs");Spacer(Modifier.weight(1f));Text("$dpp");IconButton({if(dpp>0)dpp--}){Icon(Icons.Default.Remove,null)};IconButton({dpp++}){Icon(Icons.Default.Add,null)}};Button({vm.addStructure(c,lec,dpp)},Modifier.fillMaxWidth()){Text("Lock Structure")}}}};item{CheckpointGroup(vm,c,"Lectures",c.lectures,"lec")};item{CheckpointGroup(vm,c,"DPPs",c.dpps,"dpp")};item{CheckpointGroup(vm,c,"Revision — exactly 5",c.revisions,"rev")};item{CardBox{Column(Modifier.padding(16.dp)){listOf("NCERT" to "ncert","PYQ" to "pyq","Test" to "test").forEach{(a,k)->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(a);Spacer(Modifier.weight(1f));Button({vm.toggleCheckpoint(c,k)}){Text(if(vm.checkpoint(c,k))"Done ✓" else "Mark done")};Button({vm.addBatch(c,k)}){Text("Batch")}}}}}}}
fun SyncapsoVM.checkpoint(c:Chapter,k:String)=when(k){"ncert"->c.ncert;"pyq"->c.pyq;else->c.test}
@Composable fun CheckpointGroup(vm:SyncapsoVM,c:Chapter,title:String,list:MutableList<Boolean>,kind:String)=CardBox{Column(Modifier.padding(16.dp)){Text(title,fontWeight=UiFontWeight.Bold);if(list.isEmpty())Text("No ${kind.uppercase()} planned",color=Color.Gray,Modifier.padding(top=8.dp));list.forEachIndexed{i,v->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("${title.substringBefore(' ')} ${i+1}");Spacer(Modifier.weight(1f));Button({vm.toggleCheckpoint(c,kind,i)}){Text(if(v)"Done ✓" else "Mark done")};TextButton({vm.addBatch(c,kind,i)}){Text("Batch")}}}}}

@Composable fun Todos(vm:SyncapsoVM){Column(Modifier.fillMaxSize()){Header("To-Do","Manual + chapter-synced tasks");Row(Modifier.padding(horizontal=16.dp)){OutlinedTextField(vm.manualText,{vm.manualText=it},label={Text("Add a task")},modifier=Modifier.weight(1f));IconButton({vm.addManual()}){Icon(Icons.Default.Add,null)}};LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(vm.todos){t->CardBox{Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(t.done,{vm.toggleTodo(t)});Text(t.text,modifier=Modifier.weight(1f),fontWeight=if(t.batch)UiFontWeight.SemiBold else UiFontWeight.Normal);if(t.batch)Text("BATCH",fontSize=10.sp,color=Purple)}}}}}}

@Composable fun History(vm:SyncapsoVM){val mins=vm.todayMinutes();Column(Modifier.fillMaxSize()){Header("Study History","Your consistency at a glance");CardBox(Modifier.padding(16.dp)){Column(Modifier.padding(20.dp)){Text("Today",color=Color.Gray);Text("$mins minutes",fontSize=34.sp,fontWeight=UiFontWeight.Bold);Text("Weekly and monthly calendar will use the same saved study log in the production build.",color=Color.Gray,modifier=Modifier.padding(top=8.dp))}}}}

@Composable fun AI(vm:SyncapsoVM){Column(Modifier.fillMaxSize()){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("AI Tutor",fontSize=28.sp,fontWeight=UiFontWeight.Bold);Text("NEET doubts • concepts • revision",color=Color.Gray)}TextButton({vm.clearChat()}){Text("Clear")}};LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(vm.chats){m->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.role=="user")Arrangement.End else Arrangement.Start){Surface(shape=RoundedCornerShape(18.dp),color=if(m.role=="user")Purple else Color.White){Text(m.text,color=if(m.role=="user")Color.White else Color.DarkGray,modifier=Modifier.padding(14.dp))}}}};Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(vm.aiText,{vm.aiText=it},label={Text("Ask your doubt...")},modifier=Modifier.weight(1f));IconButton({vm.askAI()}){Icon(Icons.Default.Send,null)}}}}
}
}
