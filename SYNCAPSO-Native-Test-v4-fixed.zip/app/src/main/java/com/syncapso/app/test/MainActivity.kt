package com.syncapso.app.test

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

private val Lavender = Color(0xFFF7F4FF)
private val Purple = Color(0xFF7357E8)
private val Green = Color(0xFF38B979)

// Native data model. These types are intentionally public because they are used by
// public composable functions and extension functions below.
data class Todo(
    val id: String,
    val text: String,
    var done: Boolean,
    val chapterId: String? = null,
    val kind: String? = null,
    val index: Int? = null,
    val batch: Boolean = false
)

data class Chapter(
    val id: String,
    val subject: String,
    var name: String,
    var locked: Boolean = false,
    val lectures: MutableList<Boolean> = mutableListOf(),
    val dpps: MutableList<Boolean> = mutableListOf(),
    val revisions: MutableList<Boolean> = MutableList(5) { false },
    var ncert: Boolean = false,
    var pyq: Boolean = false,
    var test: Boolean = false
)

data class Chat(val role: String, val text: String)

class SyncapsoVM(private val context: Context) : ViewModel() {
    private val prefs = context.getSharedPreferences("syncapso_native_test", Context.MODE_PRIVATE)

    var screen by mutableStateOf("Home")
        private set
    var subject by mutableStateOf("All")
    var todos by mutableStateOf(loadTodos())
    var chapters by mutableStateOf(loadChapters())
    var chats by mutableStateOf(loadChats())
    var selectedChapter by mutableStateOf<String?>(null)
    var timerRunning by mutableStateOf(false)
        private set
    var timerStarted by mutableStateOf(0L)
        private set
    var clockNow by mutableLongStateOf(System.currentTimeMillis())
        private set
    var manualText by mutableStateOf("")
    var aiText by mutableStateOf("")
    var aiBusy by mutableStateOf(false)

    init {
        recoverTimer()
        viewModelScope.launch {
            while (true) {
                clockNow = System.currentTimeMillis()
                delay(500)
            }
        }
    }

    fun todayMinutes(): Int = prefs.getInt("today_minutes", 0)

    private fun loadTodos(): MutableList<Todo> {
        val array = JSONArray(prefs.getString("todos", "[]"))
        return MutableList(array.length()) { index ->
            val obj = array.getJSONObject(index)
            Todo(
                id = obj.getString("id"),
                text = obj.getString("text"),
                done = obj.optBoolean("done"),
                chapterId = obj.optString("cid").ifBlank { null },
                kind = obj.optString("kind").ifBlank { null },
                index = if (obj.has("idx") && !obj.isNull("idx")) obj.optInt("idx") else null,
                batch = obj.optBoolean("batch")
            )
        }
    }

    private fun saveTodos() {
        val array = JSONArray()
        todos.forEach { todo ->
            array.put(
                JSONObject().apply {
                    put("id", todo.id)
                    put("text", todo.text)
                    put("done", todo.done)
                    put("cid", todo.chapterId)
                    put("kind", todo.kind)
                    put("idx", todo.index)
                    put("batch", todo.batch)
                }
            )
        }
        prefs.edit().putString("todos", array.toString()).apply()
    }

    private fun loadChapters(): MutableList<Chapter> {
        val array = JSONArray(prefs.getString("chapters", "[]"))
        return MutableList(array.length()) { index ->
            val obj = array.getJSONObject(index)
            Chapter(
                id = obj.getString("id"),
                subject = obj.getString("subject"),
                name = obj.getString("name"),
                locked = obj.optBoolean("locked"),
                lectures = readBools(obj.optJSONArray("lec")),
                dpps = readBools(obj.optJSONArray("dpp")),
                revisions = readBools(obj.optJSONArray("rev"), 5),
                ncert = obj.optBoolean("ncert"),
                pyq = obj.optBoolean("pyq"),
                test = obj.optBoolean("test")
            )
        }
    }

    private fun readBools(array: JSONArray?, size: Int? = null): MutableList<Boolean> {
        val count = size ?: array?.length() ?: 0
        return MutableList(count) { index -> array?.optBoolean(index) ?: false }
    }

    private fun saveChapters() {
        val array = JSONArray()
        chapters.forEach { chapter ->
            array.put(
                JSONObject().apply {
                    put("id", chapter.id)
                    put("subject", chapter.subject)
                    put("name", chapter.name)
                    put("locked", chapter.locked)
                    put("lec", JSONArray().apply { chapter.lectures.forEach { put(it) } })
                    put("dpp", JSONArray().apply { chapter.dpps.forEach { put(it) } })
                    put("rev", JSONArray().apply { chapter.revisions.forEach { put(it) } })
                    put("ncert", chapter.ncert)
                    put("pyq", chapter.pyq)
                    put("test", chapter.test)
                }
            )
        }
        prefs.edit().putString("chapters", array.toString()).apply()
    }

    private fun loadChats(): MutableList<Chat> {
        val array = JSONArray(prefs.getString("chats", "[]"))
        return MutableList(array.length()) { index ->
            val obj = array.getJSONObject(index)
            Chat(obj.getString("r"), obj.getString("t"))
        }
    }

    private fun saveChats() {
        val array = JSONArray()
        chats.forEach { chat ->
            array.put(JSONObject().put("r", chat.role).put("t", chat.text))
        }
        prefs.edit().putString("chats", array.toString()).apply()
    }

    private fun recoverTimer() {
        val startedAt = prefs.getLong("active_timer", 0L)
        if (startedAt <= 0L) return
        val minutes = ((System.currentTimeMillis() - startedAt) / 60_000L).coerceAtLeast(0L)
        prefs.edit().remove("active_timer").apply()
        if (minutes > 0L) {
            val total = prefs.getInt("today_minutes", 0) + minutes.toInt()
            prefs.edit().putInt("today_minutes", total).apply()
        }
    }

    fun go(destination: String) {
        screen = destination
    }

    fun startStop() {
        if (!timerRunning) {
            timerStarted = System.currentTimeMillis()
            timerRunning = true
            prefs.edit().putLong("active_timer", timerStarted).commit()
        } else {
            val minutes = ((System.currentTimeMillis() - timerStarted) / 60_000L).coerceAtLeast(1L)
            val total = prefs.getInt("today_minutes", 0) + minutes.toInt()
            prefs.edit().putInt("today_minutes", total).remove("active_timer").commit()
            timerRunning = false
            timerStarted = 0L
        }
    }

    fun addChapter(subject: String, name: String) {
        chapters = (chapters + Chapter(UUID.randomUUID().toString(), subject, name)).toMutableList()
        saveChapters()
    }

    fun addStructure(chapter: Chapter, lectureCount: Int, dppCount: Int) {
        if (chapter.locked) return
        repeat(lectureCount.coerceAtLeast(0)) { chapter.lectures.add(false) }
        repeat(dppCount.coerceAtLeast(0)) { chapter.dpps.add(false) }
        chapter.locked = true
        saveChapters()
        chapters = chapters.toMutableList()
    }

    fun toggleCheckpoint(chapter: Chapter, kind: String, index: Int? = null) {
        when (kind) {
            "lec" -> if (index != null && index in chapter.lectures.indices) chapter.lectures[index] = !chapter.lectures[index]
            "dpp" -> if (index != null && index in chapter.dpps.indices) chapter.dpps[index] = !chapter.dpps[index]
            "rev" -> if (index != null && index in chapter.revisions.indices) chapter.revisions[index] = !chapter.revisions[index]
            "ncert" -> chapter.ncert = !chapter.ncert
            "pyq" -> chapter.pyq = !chapter.pyq
            "test" -> chapter.test = !chapter.test
        }
        todos.firstOrNull { todo ->
            todo.batch && todo.chapterId == chapter.id && todo.kind == kind && todo.index == index
        }?.let { todo ->
            todo.done = checkpointDone(chapter, kind, index)
        }
        saveChapters()
        saveTodos()
        chapters = chapters.toMutableList()
        todos = todos.toMutableList()
    }

    private fun checkpointDone(chapter: Chapter, kind: String, index: Int?): Boolean {
        return when (kind) {
            "lec" -> index != null && chapter.lectures.getOrNull(index) == true
            "dpp" -> index != null && chapter.dpps.getOrNull(index) == true
            "rev" -> index != null && chapter.revisions.getOrNull(index) == true
            "ncert" -> chapter.ncert
            "pyq" -> chapter.pyq
            "test" -> chapter.test
            else -> false
        }
    }

    fun checkpoint(chapter: Chapter, kind: String): Boolean {
        return when (kind) {
            "ncert" -> chapter.ncert
            "pyq" -> chapter.pyq
            else -> chapter.test
        }
    }

    fun addBatch(chapter: Chapter, kind: String, index: Int? = null) {
        val exists = todos.any { todo ->
            todo.batch && todo.chapterId == chapter.id && todo.kind == kind && todo.index == index
        }
        if (exists) return
        val todo = Todo(
            id = UUID.randomUUID().toString(),
            text = batchLabel(chapter, kind, index),
            done = checkpointDone(chapter, kind, index),
            chapterId = chapter.id,
            kind = kind,
            index = index,
            batch = true
        )
        todos = (todos + todo).toMutableList()
        saveTodos()
    }

    private fun batchLabel(chapter: Chapter, kind: String, index: Int?): String {
        return when (kind) {
            "lec" -> "${chapter.name} • Lecture ${(index ?: 0) + 1}"
            "dpp" -> "${chapter.name} • DPP ${(index ?: 0) + 1}"
            "rev" -> "${chapter.name} • Revision ${(index ?: 0) + 1}"
            "ncert" -> "${chapter.name} • NCERT"
            "pyq" -> "${chapter.name} • PYQ"
            else -> "${chapter.name} • Test"
        }
    }

    fun toggleTodo(todo: Todo) {
        todo.done = !todo.done
        if (todo.batch) {
            chapters.firstOrNull { it.id == todo.chapterId }?.let { chapter ->
                when (todo.kind) {
                    "lec" -> todo.index?.let { index -> if (index in chapter.lectures.indices) chapter.lectures[index] = todo.done }
                    "dpp" -> todo.index?.let { index -> if (index in chapter.dpps.indices) chapter.dpps[index] = todo.done }
                    "rev" -> todo.index?.let { index -> if (index in chapter.revisions.indices) chapter.revisions[index] = todo.done }
                    "ncert" -> chapter.ncert = todo.done
                    "pyq" -> chapter.pyq = todo.done
                    "test" -> chapter.test = todo.done
                }
            }
        }
        saveTodos()
        saveChapters()
        todos = todos.toMutableList()
        chapters = chapters.toMutableList()
    }

    fun addManual() {
        val value = manualText.trim()
        if (value.isEmpty()) return
        todos = (todos + Todo(UUID.randomUUID().toString(), value, false)).toMutableList()
        manualText = ""
        saveTodos()
    }

    fun clearChat() {
        chats = mutableListOf()
        saveChats()
    }

    fun askAI() {
        val question = aiText.trim()
        if (question.isEmpty() || aiBusy) return
        chats = (chats + Chat("user", question)).toMutableList()
        aiText = ""
        saveChats()
        aiBusy = true
        viewModelScope.launch {
            val answer = try {
                callBackend(question)
            } catch (error: Exception) {
                "AI connection error: ${error.message ?: "Please try again."}"
            }
            chats = (chats + Chat("assistant", answer)).toMutableList()
            saveChats()
            aiBusy = false
        }
    }

    private suspend fun callBackend(question: String): String = withContext(Dispatchers.IO) {
        val connection = URL("https://syncapso.onrender.com/api/ai").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 60_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")

            val history = JSONArray()
            chats.takeLast(12).forEach { chat ->
                history.put(JSONObject().put("role", chat.role).put("content", chat.text))
            }

            val body = JSONObject()
                .put("message", question)
                .put("history", history)
                .put("context", JSONObject().put("app", "SYNCAPSO").put("mode", "NEET tutor"))
                .toString()

            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader().use { reader -> reader.readText() }
            if (responseCode !in 200..299) throw IllegalStateException("HTTP $responseCode")

            val response = JSONObject(responseText)
            response.optString("reply")
                .ifBlank { response.optString("message") }
                .ifBlank { response.optString("content") }
                .ifBlank { "I received the response, but it had no text." }
        } finally {
            connection.disconnect()
        }
    }

    fun elapsedMillis(): Long {
        if (!timerRunning) return 0L
        return (clockNow - timerStarted).coerceAtLeast(0L)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: SyncapsoVM = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return SyncapsoVM(applicationContext) as T
                    }
                }
            )
            SyncapsoApp(vm)
        }
    }
}

@Composable
fun SyncapsoApp(vm: SyncapsoVM) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            background = Lavender,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Lavender,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val destinations = listOf(
                        "Home" to Icons.Default.Home,
                        "Chapters" to Icons.Default.MenuBook,
                        "To-Do" to Icons.Default.CheckCircle,
                        "History" to Icons.Default.CalendarMonth,
                        "AI" to Icons.Default.SmartToy
                    )
                    destinations.forEach { (name, icon) ->
                        NavigationBarItem(
                            selected = vm.screen == name,
                            onClick = { vm.go(name) },
                            icon = { Icon(icon, contentDescription = name) },
                            label = { Text(name) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
            ) {
                when (vm.screen) {
                    "Home" -> HomeScreen(vm)
                    "Chapters" -> ChaptersScreen(vm)
                    "Chapter" -> {
                        val selected = vm.selectedChapter?.let { id -> vm.chapters.firstOrNull { it.id == id } }
                        if (selected == null) ChaptersScreen(vm) else ChapterDetailScreen(vm, selected)
                    }
                    "To-Do" -> TodosScreen(vm)
                    "History" -> HistoryScreen(vm)
                    "AI" -> AiScreen(vm)
                    else -> HomeScreen(vm)
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String = "") {
    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (subtitle.isNotBlank()) Text(subtitle, color = Color.Gray, fontSize = 14.sp)
    }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        content = content
    )
}

@Composable
fun HomeScreen(vm: SyncapsoVM) {
    val elapsed = vm.elapsedMillis()
    val hours = elapsed / 3_600_000L
    val minutes = (elapsed / 60_000L) % 60L
    val seconds = (elapsed / 1_000L) % 60L

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header("Good morning 👋", "Your NEET study dashboard") }
        item {
            CardBox {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Study timer", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        String.format("%02d:%02d:%02d", hours, minutes, seconds),
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = { vm.startStop() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (vm.timerRunning) "Stop & Save" else "Start studying")
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Today", "${vm.todayMinutes()} min", Modifier.weight(1f))
                MetricCard("Tasks", "${vm.todos.count { !it.done }} left", Modifier.weight(1f))
            }
        }
        item {
            CardBox {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Today’s To-Do", fontWeight = FontWeight.Bold)
                    vm.todos.filter { !it.done }.take(4).forEach { todo ->
                        Text("• ${todo.text}", modifier = Modifier.padding(top = 8.dp))
                    }
                    if (vm.todos.none { !it.done }) {
                        Text("All clear 🎉", modifier = Modifier.padding(top = 8.dp), color = Green)
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    CardBox(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, color = Color.Gray)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}

@Composable
fun ChaptersScreen(vm: SyncapsoVM) {
    var showDialog by remember { mutableStateOf(false) }
    val filtered = vm.chapters.filter { vm.subject == "All" || it.subject == vm.subject }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header("Chapters", "Build your study structure") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Physics", "Chemistry", "Biology").forEach { value ->
                    FilterChip(
                        selected = vm.subject == value,
                        onClick = { vm.subject = value },
                        label = { Text(value) }
                    )
                }
            }
        }
        items(filtered, key = { it.id }) { chapter ->
            CardBox(
                modifier = Modifier.clickable {
                    vm.selectedChapter = chapter.id
                    vm.go("Chapter")
                }
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(chapter.subject.uppercase(), color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(chapter.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${chapter.lectures.count { it }}/${chapter.lectures.size} lectures • " +
                            "${chapter.dpps.count { it }}/${chapter.dpps.size} DPPs • " +
                            "${chapter.revisions.count { it }}/5 revisions",
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 5.dp)
                    )
                    LinearProgressIndicator(
                        progress = { chapterProgress(chapter) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    )
                }
            }
        }
        item {
            Button(
                onClick = { showDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.size(6.dp))
                Text("Add chapter")
            }
        }
    }

    if (showDialog) {
        AddChapterDialog(
            onConfirm = { subject, name ->
                vm.addChapter(subject, name)
                showDialog = false
            },
            onCancel = { showDialog = false }
        )
    }
}

fun chapterProgress(chapter: Chapter): Float {
    val completed = chapter.lectures.count { it } +
        chapter.dpps.count { it } +
        chapter.revisions.count { it } +
        listOf(chapter.ncert, chapter.pyq, chapter.test).count { it }
    val total = chapter.lectures.size + chapter.dpps.size + 8
    return (completed.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f)
}

@Composable
fun AddChapterDialog(onConfirm: (String, String) -> Unit, onCancel: () -> Unit) {
    var selectedSubject by remember { mutableStateOf("Physics") }
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("New chapter") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("Physics", "Chemistry", "Biology").forEach { value ->
                        FilterChip(
                            selected = selectedSubject == value,
                            onClick = { selectedSubject = value },
                            label = { Text(value) }
                        )
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Chapter name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onConfirm(selectedSubject, name.trim()) }
            ) { Text("Add") }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text("Cancel") }
        }
    )
}

@Composable
fun ChapterDetailScreen(vm: SyncapsoVM, chapter: Chapter) {
    var lectureCount by remember(chapter.id) { mutableIntStateOf(chapter.lectures.size) }
    var dppCount by remember(chapter.id) { mutableIntStateOf(chapter.dpps.size) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Header(chapter.name, chapter.subject) }
        if (!chapter.locked) {
            item {
                CardBox {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Plan structure", fontWeight = FontWeight.Bold)
                        CounterRow("Lectures", lectureCount, onMinus = { if (lectureCount > 0) lectureCount-- }, onPlus = { lectureCount++ })
                        CounterRow("DPPs", dppCount, onMinus = { if (dppCount > 0) dppCount-- }, onPlus = { dppCount++ })
                        Button(
                            onClick = { vm.addStructure(chapter, lectureCount, dppCount) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Lock Structure") }
                    }
                }
            }
        }
        item { CheckpointGroup(vm, chapter, "Lectures", chapter.lectures, "lec") }
        item { CheckpointGroup(vm, chapter, "DPPs", chapter.dpps, "dpp") }
        item { CheckpointGroup(vm, chapter, "Revision — exactly 5", chapter.revisions, "rev") }
        item {
            CardBox {
                Column(modifier = Modifier.padding(16.dp)) {
                    listOf("NCERT" to "ncert", "PYQ" to "pyq", "Test" to "test").forEach { (label, kind) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label)
                            Spacer(modifier = Modifier.weight(1f))
                            Button(onClick = { vm.toggleCheckpoint(chapter, kind) }) {
                                Text(if (vm.checkpoint(chapter, kind)) "Done ✓" else "Mark done")
                            }
                            TextButton(onClick = { vm.addBatch(chapter, kind) }) { Text("Batch") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CounterRow(label: String, value: Int, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label)
        Spacer(modifier = Modifier.weight(1f))
        Text(value.toString())
        IconButton(onClick = onMinus) { Icon(Icons.Default.Remove, contentDescription = "Decrease") }
        IconButton(onClick = onPlus) { Icon(Icons.Default.Add, contentDescription = "Increase") }
    }
}

@Composable
fun CheckpointGroup(
    vm: SyncapsoVM,
    chapter: Chapter,
    title: String,
    checkpoints: MutableList<Boolean>,
    kind: String
) {
    CardBox {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (checkpoints.isEmpty()) {
                Text("No ${kind.uppercase()} planned", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
            }
            checkpoints.forEachIndexed { index, done ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${title.substringBefore(' ')} ${index + 1}")
                    Spacer(modifier = Modifier.weight(1f))
                    Button(onClick = { vm.toggleCheckpoint(chapter, kind, index) }) {
                        Text(if (done) "Done ✓" else "Mark done")
                    }
                    TextButton(onClick = { vm.addBatch(chapter, kind, index) }) { Text("Batch") }
                }
            }
        }
    }
}

@Composable
fun TodosScreen(vm: SyncapsoVM) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header("To-Do", "Manual + chapter-synced tasks")
        Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = vm.manualText,
                onValueChange = { vm.manualText = it },
                label = { Text("Add a task") },
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { vm.addManual() }) {
                Icon(Icons.Default.Add, contentDescription = "Add task")
            }
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(vm.todos, key = { it.id }) { todo ->
                CardBox {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = todo.done, onCheckedChange = { vm.toggleTodo(todo) })
                        Text(
                            todo.text,
                            modifier = Modifier.weight(1f),
                            fontWeight = if (todo.batch) FontWeight.SemiBold else FontWeight.Normal
                        )
                        if (todo.batch) Text("BATCH", fontSize = 10.sp, color = Purple)
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: SyncapsoVM) {
    val minutes = vm.todayMinutes()
    Column(modifier = Modifier.fillMaxSize()) {
        Header("Study History", "Your consistency at a glance")
        CardBox(modifier = Modifier.padding(16.dp)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Today", color = Color.Gray)
                Text("$minutes minutes", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(
                    "This native test stores study time locally so the session survives app restarts.",
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
fun AiScreen(vm: SyncapsoVM) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("AI Tutor", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("NEET doubts • concepts • revision", color = Color.Gray)
            }
            TextButton(onClick = { vm.clearChat() }) { Text("Clear") }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.chats) { message ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (message.role == "user") Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (message.role == "user") Purple else Color.White
                    ) {
                        Text(
                            text = message.text,
                            color = if (message.role == "user") Color.White else Color.DarkGray,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }
            if (vm.aiBusy) {
                item { Text("AI Tutor is thinking…", color = Color.Gray) }
            }
        }

        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = vm.aiText,
                onValueChange = { vm.aiText = it },
                label = { Text("Ask your doubt...") },
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { vm.askAI() }) {
                Icon(Icons.Default.Send, contentDescription = "Send")
            }
        }
    }
}
